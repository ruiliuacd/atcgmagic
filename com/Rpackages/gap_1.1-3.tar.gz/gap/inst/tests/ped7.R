library(gap)
makeped("ped7.pre","ped7.ped",0,1,"ped7.lop")
makeped
? makeped
q('no')
